repchain_data_functions
-----------------------
Collection of functions to calculate figures of merit from raw QKD simulation data.

.. automodule:: netsquid_simulationtools.repchain_data_functions
    :members:
