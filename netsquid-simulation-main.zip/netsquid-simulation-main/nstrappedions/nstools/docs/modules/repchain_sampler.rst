repchain_sampler
-------------------------
State Sampler that creates tree structure directly from :class:`~.repchain_dataframe_holder`.

.. automodule:: netsquid_simulationtools.repchain_sampler
    :members:
